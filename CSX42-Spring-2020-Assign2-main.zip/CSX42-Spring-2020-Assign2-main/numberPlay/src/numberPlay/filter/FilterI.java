package numberPlay.filter;

public interface FilterI{
  String getEvent();
}
